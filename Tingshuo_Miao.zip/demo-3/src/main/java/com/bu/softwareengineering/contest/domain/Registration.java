package com.bu.softwareengineering.contest.domain;

public class Registration {

}
