package com.bu.softwareengineering.contest.domain.enumeration;

/**
 * The State enumeration.
 */
public enum State {
    ACCEPTED, PENDING, CANCELLED
}
