package com.bu.softwareengineering.contest.Service;

import com.bu.softwareengineering.contest.domain.Contest;
import com.bu.softwareengineering.contest.domain.Team;
import com.bu.softwareengineering.contest.domain.TeamMember;
import com.bu.softwareengineering.contest.repository.ContestManagerRepository;
import com.bu.softwareengineering.contest.repository.ContestRepository;
import com.bu.softwareengineering.contest.repository.ContestTeamRepository;
import com.bu.softwareengineering.contest.repository.TeamRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import com.bu.softwareengineering.contest.domain.ContestTeam;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;

@Service
public class RegisService {
    @Autowired
    ContestRepository contestRepository;
    @Autowired
    TeamRepository teamRepository;
    private EntityManager entityManager;
    @Autowired
    ContestTeamRepository contestteamRepository;

    @Autowired
    ContestManagerRepository contestManagerRepository;

    public void RefreashCapacity(){
        List<Contest> contests = contestRepository.findAll();
        for(Contest i : contests){
            int capacity = 0;
            //Get capacity for all teams
            Set<ContestTeam> teams = i.getContestTeams();
            for(ContestTeam contestTeamteam : teams){
                Team team = contestTeamteam.getTeam();
                if(team.getCloneOf()!=null){
                    continue;
                }
                Set<TeamMember> members = team.getTeamMembers();
                for(TeamMember teamMember : members){
                    capacity++;
                }
            }

            //Get capacity for subContest
            Set<Contest> contestSet = i.getContests();
            for(Contest contest : contestSet){
                Set<ContestTeam> subteams = contest.getContestTeams();
                for(ContestTeam contestTeamteam : subteams){
                    Team team = contestTeamteam.getTeam();
                    Set<TeamMember> members = team.getTeamMembers();
                    for(TeamMember teamMember : members){
                        capacity++;
                    }
                }
            }
            i.setCurrent_capacity(capacity);
            contestRepository.save(i);
        }
    }

    public Map Team_setEditable(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("team").asLong();
        Team team = teamRepository.findById(contest_id).get();
        team.setWritable(true);
        teamRepository.save(team);
        respose.put("success", "Team " + team.getName() + " is writable now.");
        return respose;
    }

    public Map Team_setReadOnly(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("team").asLong();
        Team team = teamRepository.findById(contest_id).get();
        team.setWritable(false);
        teamRepository.save(team);
        respose.put("success", "Team " + team.getName() + " is read only now.");
        return respose;
    }



    public Map Contest_setEditable(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("contest").asLong();
        Contest contest = contestRepository.findById(contest_id).get();
        contest.setWritable(true);
        contestRepository.save(contest);
        respose.put("success", "Contest " + contest.getName() + " is writable now.");
        return respose;
    }

    public Map Contest_setReadOnly(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("contest").asLong();
        Contest contest = contestRepository.findById(contest_id).get();
        contest.setWritable(false);
        contestRepository.save(contest);
        respose.put("success", "Contest " + contest.getName() + " is read only now.");
        return respose;
    }

    public Map editTeam(Team team){
        Map respose = new HashMap();
        Long team_id = team.getId();
        Team oldteam = teamRepository.findById(team_id).get();
        if(oldteam.getWritable()==false){
            respose.put("error","This team is not writable.");
            return respose;
        }
        List<Team> allteams = teamRepository.findAll();
        List<String> names = new ArrayList<>();
        for(Team i : allteams){
            names.add(i.getName());
        }
        if(names.contains(team.getName())){
            respose.put("error","This team name is used by other teams.");
            return respose;
        }
        oldteam.setName(team.getName());
        oldteam.setCoach(team.getCoach());
        oldteam.setContestTeams(team.getContestTeams());
        oldteam.setRank(team.getRank());
        oldteam.setState(team.getState());
        oldteam.setTeamMembers(team.getTeamMembers());
        teamRepository.save(oldteam);
        respose.put("success","Your edit is successful.");
        RefreashCapacity();
        return respose;
    }

    public Map editContest(Contest contest){
        Map respose = new HashMap();
        Long contest_id = contest.getId();
        Contest oldcontest = contestRepository.findById(contest_id).get();
        if(oldcontest.getWritable()==false){
            respose.put("error","This contest is not writable.");
            return respose;
        }
        oldcontest.setContests(contest.getContests());
        List<Contest> allteams = contestRepository.findAll();
        List<String> names = new ArrayList<>();
        for(Contest i : allteams){
            names.add(i.getName());
        }
        if(names.contains(contest.getName())){
            respose.put("error","This team name is used by other teams.");
            return respose;
        }
        oldcontest.setName(contest.getName());
        oldcontest.setCurrent_capacity(contest.getCurrent_capacity());
        oldcontest.setContestManagers(contest.getContestManagers());
        oldcontest.setCapacity(contest.getCapacity());
        oldcontest.setContestTeams(contest.getContestTeams());
        oldcontest.setParent(contest.getParent());
        oldcontest.setDate(contest.getDate());
        oldcontest.setRegistrationAllowed(contest.getRegistrationAllowed());
        oldcontest.setRegistrationFrom(contest.getRegistrationFrom());
        oldcontest.setRegistrationTo(contest.getRegistrationTo());
        contestRepository.save(oldcontest);
        respose.put("success","Your edit is successful.");
        RefreashCapacity();
        return respose;
    }

    public Map Regis(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("contest").asLong();
        ArrayNode arrayNode = (ArrayNode) file.get("teams");
        Contest contest = contestRepository.findById(contest_id).get();
        Set<ContestTeam> contestTeam = contest.getContestTeams();
        List<Long> ids = new ArrayList<>();
        List<Long> people = new ArrayList<>();

//        contest.setName("CONTEST-001-SUB2\t");
//        contestRepository.save(contest);
        int team_size = 0;
        for(int j = 0; j<arrayNode.size();j++){
            Team a = teamRepository.findById(arrayNode.get(j).asLong()).get();
            people.add(a.getCoach().getId());
            if(ids.contains(arrayNode.get(j).asLong())){
                respose.put("erroMesage ","Team " + a.getName() +" is duplicated");
            }
            ids.add(arrayNode.get(j).asLong());
            List<Long> in_inContest = new ArrayList<>();
            Set<ContestTeam> teams = contest.getContestTeams();
            for(ContestTeam contestTeamteam : teams){
                Team team = contestTeamteam.getTeam();
                Set<TeamMember> members = team.getTeamMembers();
                for(TeamMember teamMember : members){
                    long id = teamMember.getPerson().getId();
                    in_inContest.add(id);
                }
            }

            for(ContestTeam i : contestTeam){
                Team team = i.getTeam();
                if(team.getId() == a.getId()){
                    String teamname = a.getName();
                    String contestname = contest.getName();
                    respose.put("erroMesage ", teamname + " is already in" + contestname);
                    return respose;
                }
            }

            Set<TeamMember> a_member = a.getTeamMembers();
            //Less than 24
            for(TeamMember i : a_member){
                if(people.contains(i.getPerson().getId())){
                    respose.put("erroMesage ", i.getPerson().getName() + " is duplicated in contest or in team");
                    return respose;
                }
                if(in_inContest.contains(i.getPerson().getId())){
                    respose.put("erroMesage ", i.getPerson().getName() + " is in another team in this contest");
                    return respose;
                }
                team_size++;
                people.add(i.getPerson().getId());
                Date birthday = i.getPerson().getBirthday();
                LocalDate date = convertToLocalDateViaMilisecond(birthday);
                if(calculateAge(date)>24){
                    respose.put("erroMesage", "TeamMember " + i.getPerson().getName() + " is more than 24");
                    return respose;
                }
            }

            int capacity = contest.getCapacity();
            int newcapa = contest.getCurrent_capacity()+team_size;
            if(newcapa>capacity){
                respose.put("erroMesage", "Capacity of the contest in overflowed");
                return respose;
            }


            ContestTeam newer = new ContestTeam();
            newer.setTeam(a);
            newer.setContest(contest);
            contestteamRepository.save(newer);
            contest.setCurrent_capacity(newcapa);
            contestRepository.save(contest);
            RefreashCapacity();
            team_size=0;
            people = new ArrayList<>();
        }













//         if ///error
//        respose.put("erroMesage", "Registernnjkfnv");
//
//         if/// success
//
        respose.put("success", "Team are registed successfully into contest");



        return respose;
    }


    public Map promote(JsonNode file){
        Map respose = new HashMap();
        Long contest_id = file.get("contest").asLong();
        ArrayNode arrayNode = (ArrayNode) file.get("teams");
        Contest contest = contestRepository.findById(contest_id).get();
        Set<ContestTeam> contestTeam = contest.getContestTeams();
        List<Long> ids = new ArrayList<>();
        List<Long> people = new ArrayList<>();

//        contest.setName("CONTEST-001-SUB2\t");
//        contestRepository.save(contest);
        int team_size = 0;
        for(int j = 0; j<arrayNode.size();j++){
            Team a = teamRepository.findById(arrayNode.get(j).asLong()).get();
            people.add(a.getCoach().getId());
            if(ids.contains(arrayNode.get(j).asLong())){
                respose.put("erroMesage ","Team " + a.getName() +" is duplicated");
            }
            ids.add(arrayNode.get(j).asLong());
            List<Long> in_inContest = new ArrayList<>();
            Set<ContestTeam> teams = contest.getContestTeams();
            for(ContestTeam contestTeamteam : teams){
                Team team = contestTeamteam.getTeam();
                Set<TeamMember> members = team.getTeamMembers();
                for(TeamMember teamMember : members){
                    long id = teamMember.getPerson().getId();
                    in_inContest.add(id);
                }
            }

            for(ContestTeam i : contestTeam){
                Team team = i.getTeam();
                if(team.getId() == a.getId()){
                    String teamname = a.getName();
                    String contestname = contest.getName();
                    respose.put("erroMesage ", teamname + " is already in" + contestname);
                    return respose;
                }
            }

            Set<TeamMember> a_member = a.getTeamMembers();
            //Less than 24
            for(TeamMember i : a_member){
                if(people.contains(i.getPerson().getId())){
                    respose.put("erroMesage ", i.getPerson().getName() + " is duplicated");
                    return respose;
                }
                if(in_inContest.contains(i.getPerson().getId())){
                    respose.put("erroMesage ", i.getPerson().getName() + " is in another team in this contest");
                    return respose;
                }
                team_size++;
                people.add(i.getPerson().getId());
                Date birthday = i.getPerson().getBirthday();
                LocalDate date = convertToLocalDateViaMilisecond(birthday);
                if(calculateAge(date)>24){
                    respose.put("erroMesage", "TeamMember " + i.getPerson().getName() + " is more than 24");
                    return respose;
                }
            }

            int capacity = contest.getCapacity();
            int newcapa = contest.getCurrent_capacity()+team_size;
            if(newcapa>capacity){
                respose.put("erroMesage", "Capacity of the contest in overflowed");
                return respose;
            }


            ContestTeam newer = new ContestTeam();
            /*Team newteam = new Team();
            newteam.setRank(a.getRank());
            newteam.setWritable(a.getWritable());
            newteam.setCoach(a.getCoach());
            newteam.setState(a.getState());
            newteam.setId(null);
            newteam.setTeamMembers(a.getTeamMembers());
            newteam.setContestTeams(a.getContestTeams());
            newteam.setName(a.getName());
            newer.setTeam(newteam);
            newer.setContest(contest);*/
            if(a.getRank()>5){
                respose.put("error","This team's rank is lower than 5.");
                return respose;
            }
            newer.setContest(contest);
            newer.setTeam(a);
            contestteamRepository.save(newer);
            Team promotedTeam = new Team();
            BeanUtils.copyProperties(a,promotedTeam);
            promotedTeam.setCloneOf(a.getId());
            promotedTeam.setId(null);
            promotedTeam.setTeamMembers(null);
            promotedTeam.setContestTeams(null);
            teamRepository.save(promotedTeam);

            //RefreashCapacity();
            team_size=0;
            people = new ArrayList<>();
        }













//         if ///error
//        respose.put("erroMesage", "Registernnjkfnv");
//
//         if/// success
//
        respose.put("success", "Team are registed successfully into contest");



        return respose;
    }



    public int calculateAge(LocalDate dob){

        LocalDate curDate = LocalDate.now();
        if ((dob != null) && (curDate != null))
        {
            return Period.between(dob, curDate).getYears();
        }
        else
        {
            return 0;
        }
    }
    public LocalDate convertToLocalDateViaMilisecond(Date dateToConvert) {
        return Instant.ofEpochMilli(dateToConvert.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }
}
