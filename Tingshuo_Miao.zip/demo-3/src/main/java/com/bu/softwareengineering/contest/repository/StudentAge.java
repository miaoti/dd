package com.bu.softwareengineering.contest.repository;

import java.util.Date;

public interface StudentAge {
    Integer getCount();
    Date getBirthday();
    String getType();
}
