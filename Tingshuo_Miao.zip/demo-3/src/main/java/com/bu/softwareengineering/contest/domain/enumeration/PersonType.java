package com.bu.softwareengineering.contest.domain.enumeration;

/**
 * The PersonType enumeration.
 */
public enum PersonType {
    STUDENT, MANAGER, COACH
}
